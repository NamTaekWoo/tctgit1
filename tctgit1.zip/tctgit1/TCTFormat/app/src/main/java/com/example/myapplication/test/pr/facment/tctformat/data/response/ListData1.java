package com.example.myapplication.test.pr.facment.tctformat.data.response;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ListData1 {
    @SerializedName("list")
    private List<Data1> list;


}
