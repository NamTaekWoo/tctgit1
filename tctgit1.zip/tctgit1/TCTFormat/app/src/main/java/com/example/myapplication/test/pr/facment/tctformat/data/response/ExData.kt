package com.example.myapplication.test.pr.facment.tctformat.data.response

class ExData {
}