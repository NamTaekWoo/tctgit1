package com.example.myapplication.test.pr.facment.tctformat.data.response;

import com.google.gson.annotations.SerializedName;

public class Data2 {
    @SerializedName("key")
    private String key;

    public String getKey() {
        return key;
    }


}
